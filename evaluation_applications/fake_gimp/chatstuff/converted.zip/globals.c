#include "globals.h"
int selected_tool = 0;
int selected_layer = 0;
float opacities[3] = {1.0, 1.0, 1.0};
